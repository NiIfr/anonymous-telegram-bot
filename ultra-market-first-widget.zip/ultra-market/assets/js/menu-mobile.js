// const list = document.querySelectorAll('.list');
// function activeLink() {
//   list.forEach((item)=>
//   item.classList.remove('active'));
//   this.classList.add('active');
// }

// list.forEach((item)=>
//   item.addEventListener('click',activeLink));


$(document).ready (function(){
  $('.floatting-btn i').click( function() {
    $('.contact-list').slideToggle();
    if($(this).hasClass('fa-comment-dots')) {
      $(this).removeClass('fa-comment-dots').addClass('fa-multiply'); 
      $(this).css({
        'transform' : 'rotate(180deg)',
      })
    }
    else {
      $(this).removeClass('fa-multiply').addClass('fa-comment-dots'); 
      $(this).css({
        'transform' : 'rotate(0deg)',
      })
    }
  })
})



// گرفتن تمامی آیتم‌های منو
const list = document.querySelectorAll('.list');

// تابع برای تنظیم کلاس active بر اساس URL فعلی
function setActiveBasedOnURL() {
  const currentURL = window.location.href.replace(/\/$/, ""); // حذف اسلش انتهایی از URL فعلی
  
  let isActiveSet = false; // برای اطمینان از اینکه یک آیتم کلاس active می‌گیرد

  list.forEach((item) => {
	const linkElement = item.querySelector('a');
    const link = linkElement?.href?.replace(/\/$/, ""); // حذف اسلش انتهایی از لینک

    // شرط برای صفحه فروشگاه
    if (currentURL.includes("/shop")) {
      if (linkElement.id === "filter-ultra") {
        item.classList.add('active'); // گزینه فیلتر را فعال می‌کند
        isActiveSet = true;
      } else if (linkElement.id === "shop") {
        item.classList.add('active'); // گزینه فروشگاه را فعال می‌کند
        isActiveSet = true;
      } else {
        item.classList.remove('active'); // حذف active از بقیه آیتم‌ها
      }
    }
	  // شرط برای صفحه فروشگاه
    else if (currentURL.includes("/product-category")) {
      if (linkElement.id === "filter-ultra") {
        item.classList.add('active'); // گزینه فیلتر را فعال می‌کند
        isActiveSet = true;
      } else if (linkElement.id === "shop") {
        item.classList.add('active'); // گزینه فروشگاه را فعال می‌کند
        isActiveSet = true;
      } else {
        item.classList.remove('active'); // حذف active از بقیه آیتم‌ها
      }
    }
    // شرط برای صفحه حساب کاربری و زیرمجموعه‌های آن
    else if (currentURL.includes("/my-account") && linkElement.id === "user") {
      item.classList.add('active');
      isActiveSet = true;
    }
    // شرط برای سایر لینک‌های منو
    else if (currentURL === link) {
      item.classList.add('active');
      isActiveSet = true;
    } else {
      item.classList.remove('active');
    }
  });

  // اگر هیچ آیتمی کلاس active نداشت، گزینه خانه را فعال کن
  if (!isActiveSet) {
    const homeItem = document.querySelector('#home');
    if (homeItem) {
      homeItem.parentElement.classList.add('active');
    }
  }
}

// اجرای تابع هنگام بارگذاری صفحه
setActiveBasedOnURL();

// اضافه کردن رویداد کلیک برای تنظیم کلاس active
list.forEach((item) => {
  item.addEventListener('click', function () {
    list.forEach((el) => el.classList.remove('active')); // حذف active از تمام آیتم‌ها
    this.classList.add('active'); // افزودن active به آیتم کلیک‌شده
  });
});












const trigger= document.querySelectorAll('nav li');
trigger.forEach((menu)=> menu.addEventListener('click',toggle));

function toggle () {
    trigger.forEach((item)=> item !=this ? item.classList.remove('active') : null);
    if (this.classList != 'active') {
        this.classList.toggle('active');
    }
}





// Get the modal
var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}


/***********timer Amazing***********/
jQuery(document).ready(function (){
  function countdownTimer() {
      var countdownElements = document.querySelectorAll('.box-timer');
      countdownElements.forEach(function (countdownElement) {
          var daysElements = countdownElement.querySelectorAll('.days-value');
          var hoursElements = countdownElement.querySelectorAll('.hours-value');
          var minutesElements = countdownElement.querySelectorAll('.minutes-value');
          var secondsElements = countdownElement.querySelectorAll('.seconds-value');
          var messageElement = countdownElement.querySelector('.timer-message');
          var messagesElement = countdownElement.querySelector('.massages-heddin');
          var targetYear = parseInt(countdownElement.dataset.targetYear);
          var targetMonth = parseInt(countdownElement.dataset.targetMonth) - 1;
          var targetDay = parseInt(countdownElement.dataset.targetDay);
          var targetHour = parseInt(countdownElement.dataset.targetHour);
          var targetMinute = parseInt(countdownElement.dataset.targetMinute);
          var targetSecond = parseInt(countdownElement.dataset.targetSecond);
          var targetDate = new Date(targetYear, targetMonth, targetDay, targetHour, targetMinute, targetSecond);

          function updateTimer() {
              var now = new Date().getTime();
              var timeRemaining = targetDate - now;
              var days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
              var hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
              var minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
              var seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);
              for (var i = 0; i < daysElements.length; i++) {
                  daysElements[i].innerHTML = days;
              }
              for (var i = 0; i < hoursElements.length; i++) {
                  hoursElements[i].innerHTML = hours;
              }
              for (var i = 0; i < minutesElements.length; i++) {
                  minutesElements[i].innerHTML = minutes;
              }
              for (var i = 0; i < secondsElements.length; i++) {
                  secondsElements[i].innerHTML = seconds;
              }
              if (timeRemaining > 0) {
                  setTimeout(updateTimer, 1000);
              } else {
                  messagesElement.style.display = 'none';
                  /*messageElement.style.display = 'block';
                  var messageTextElement = messageElement.querySelector('.timer-message-text');
                  messageTextElement.innerHTML = 'تایمر به پایان رسیده است';*/
              }
          }

          updateTimer();
      });
  }
  countdownTimer();
});



/************quantity number plus and minus************/
$(document).on( 'click', 'button.plus, button.minus', function() {
  var qty = $( this ).parent( '.quantity' ).find( '.input-text' );
  var val = parseFloat(qty.val());
  var max = parseFloat(qty.attr( 'max' ));
  var min = parseFloat(qty.attr( 'min' ));
  var step = parseFloat(qty.attr( 'step' ));
  if ( $( this ).is( '.plus' ) ) {
      if ( max && ( max <= val ) ) {
          qty.val( max ).change();
      } else {
          qty.val( val + step ).change();
      }
  } else {
      if ( min && ( min >= val ) ) {
          qty.val( min ).change();
      } else if ( val > 1 ) {
          qty.val( val - step ).change();
      }
  }
});


$(document).ready(function () {
  // دریافت المان‌های موردنظر
  var ultra_modal_share = document.getElementById("ultra-modal");
  var share_modal_btn = document.getElementById("btn_modal_video");
  var close_share_modal = document.getElementsByClassName("close_video_modal")[0];

  // بررسی وجود المان‌های موردنیاز
  if (ultra_modal_share && share_modal_btn && close_share_modal) {
    // نمایش مودال هنگام کلیک روی دکمه
    share_modal_btn.onclick = function () {
      ultra_modal_share.style.display = "block";
    };

    // بستن مودال هنگام کلیک روی دکمه "بستن"
    close_share_modal.onclick = function () {
      ultra_modal_share.style.display = "none";
    };

    // بستن مودال هنگام کلیک بیرون از آن
    window.onclick = function (event) {
      if (event.target == ultra_modal_share) {
        ultra_modal_share.style.display = "none";
      }
    };
  } else {
    console.warn("Some elements are missing: 'ultra-modal', 'btn_modal_video', or 'close_video_modal'.");
  }
});




document.addEventListener("DOMContentLoaded", function () {
  const prodShare = document.getElementById("prod-share");
  const overlayProd = document.getElementById("overlay-prod");
  const modalProdShare = document.getElementById("modal-prod-share");
  const closeBtnProdShare = document.getElementById("close-btn-prod-share");

  // بررسی وجود المان‌ها قبل از افزودن Event Listener
  if (prodShare && overlayProd && modalProdShare && closeBtnProdShare) {
    prodShare.addEventListener("click", function () {
      overlayProd.classList.add("is-visible");
      modalProdShare.classList.add("is-visible");
    });

    closeBtnProdShare.addEventListener("click", function () {
      overlayProd.classList.remove("is-visible");
      modalProdShare.classList.remove("is-visible");
    });

    overlayProd.addEventListener("click", function () {
      overlayProd.classList.remove("is-visible");
      modalProdShare.classList.remove("is-visible");
    });
  } else {
    console.warn("Some elements are missing from the DOM. Event listeners were not added.");
  }
});









//Script for panel mobile menu
  function myFunctionpanelx() {
    var panelx = document.getElementById("ultra-panel-menu");
    if (panelx.style.display === "block") {
      panelx.style.display = "none";
    } else {
      panelx.style.display = "block";
    }
  }

  
  




