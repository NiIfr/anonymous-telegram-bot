// let products = document.querySelectorAll('.message-box-ultra'); 
// let currentProductIndex = 0; 

// function showNextProduct() {
//     if (products.length === 0) return;

//     products.forEach(product => product.classList.remove('show'));

//     const currentProduct = products[currentProductIndex];
//     if (currentProduct) {   
//         currentProduct.classList.add('show');

//         setTimeout(() => {
//             currentProduct.classList.remove('show');
//         }, 7000);
//     }

//     currentProductIndex = (currentProductIndex + 1) % products.length;
// }

// setInterval(showNextProduct, 7000);
// Store the product elements in an array
const products = Array.from(document.querySelectorAll('.message-box-ultra'));
let currentProductIndex = 0;

function showNextProduct() {
    products.forEach(product => product.classList.remove('show'));
    const currentProduct = products[currentProductIndex];
    currentProduct.classList.add('show');
    setTimeout(() => {
        currentProduct.classList.remove('show');
    }, 7000);

    currentProductIndex = (currentProductIndex + 1) % products.length;
}

function closeMessage() {
    const currentProduct = products.find(product => product.classList.contains('show'));
    if (currentProduct) {
        currentProduct.classList.remove('show');
    }
}

if (!window.location.pathname.includes("wp-admin")) {

    setTimeout(() => {
        showNextProduct();
    }, 7000);

    setInterval(() => {
        showNextProduct();
    }, 30000);
}




		$('.ultra-product-little-grid_slider').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    rtl:true,
    responsive:{
        0:{
            items:1.2
        },
        600:{
            items:2.2
        },
        1400:{
            items:5.2
        },
		1500:{
            items:6.3
        }
    }
});
		
// $('.ultra-brands-widget_slider').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:true,
//     dots:false,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1.2
//         },
//         600:{
//             items:2.2
//         },
//         1400:{
//             items:3.2
//         },
// 		1500:{
//             items:5
//         }
//     }
// });


// $('.ultra-comment-widget_slider').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:false,
//     dots:true,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:1
//         },
//         1000:{
//             items:1
//         }
//     }
// });

// // $('.slider').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:true,
//     dots:true,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:1
//         },
//         1000:{
//             items:1
//         }
//     }
// });

// $('.loop').owlCarousel({
//     center: true,
//     items:1,
//     loop:true,
//     dots:false,
//     margin:10,
//     rtl:true,
//     responsive:{
//         480:{
//             items:1
//         },
//         602:{
//             items:2
//         },
//         1024:{
//             items:3
//         },
//         1280:{
//             items:4
//         },
//         1600:{
//             items:5
//         }
//     }
// });

// $('.choosen-prod').owlCarousel({
//     center: false,
//     loop:false,
//     dots:false,
//     margin:20,
//     rtl:true,
//     responsive:{
//         430:{
//             items:1
//         },
//         570:{
//             items:2
//         },
//         601:{
//             items:2
//         },
//         1024:{
//             items:4
//         },
//         1366:{
//             items:5
//         },
//         1622:{
//             items:5
//         }
//     }
// });

// $('.blog-slider').owlCarousel({
//     center: false,
//     loop:false,
//     dots:false,
//     margin:20,
//     rtl:true,
//     responsive:{
    
//         1622:{
//             items:3
//         }
//     }
// });

// $('.style-product').owlCarousel({
//     center: true,
//     items:1,
//     loop:true,
//     dots:false,
//     margin:10,
//     rtl:true,
//     responsive:{
//         480:{
//             items:2
//         },
//         601:{
//             items:2
//         },
//         1280:{
//             items:4
//         },
//         1366:{
//             items:5
//         },
//         1622:{
//             items:6
//         }
//     }
// });


// $('.brand').owlCarousel({
//     center: true,
//     items:1,
//     loop:true,
//     dots:false,
//     margin:10,
//     nav:true,
//     rtl:true,
//     responsive:{
//         601:{
//             items:1
//         },
//         1024:{
//             items:2
//         },
//         1280:{
//             items:4
//         }
//     }
// });




// $('.best-prod').owlCarousel({
//     loop:true,
//     margin:10,
//     pullDrag:true,
//     dots:true,
//     dotsData:true,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:1
//         },
//         1000:{
//             items:1
//         }
//     }
// });

// $('.related-products-prod').owlCarousel({
//     center: false,
//     loop:true,
//     dots:false,
//     margin:0,
//     rtl:true,
//     responsive:{
// 		 0:{
//             items:1.2
//         },
//         430:{
//             items:1.3
//         },
// 		 480:{
//             items:1.3
//         },
// 		 570:{
//             items:1.8
//         },
		
//         612:{
//             items:2.2
//         },
//         830:{
//             items:3.2
//         },
//         1440:{
//             items:3.3
//         },
//         1600:{
//             items:3.5
//         },
// 		  1800:{
//             items:4.1
//         }
		
//     }
// });
// 
// 
// function initResponsiveSlider() {
//   const container = document.querySelector('.product-items');
//   const containerWidth = container.offsetWidth;

//   let itemsCount = 1.2;

//   if (containerWidth > 1600) itemsCount = 6.5;
//   else if (containerWidth > 1440) itemsCount = 5.5;
// 	else if (containerWidth > 1024) itemsCount = 4.9;
//   else if (containerWidth > 830) itemsCount = 4.1;
//   else if (containerWidth > 612) itemsCount = 3.2;
//   else if (containerWidth > 570) itemsCount = 2.8;
//   else if (containerWidth > 430) itemsCount = 2.3;
//   else itemsCount = 1.2;

//   $('.related-products-prod').trigger('destroy.owl.carousel').owlCarousel({
//     center: false,
//     loop: true,
//     dots: false,
//     margin: 20,
//     rtl: true,
//     items: itemsCount,
//   });
// }

// initResponsiveSlider();

// window.addEventListener('resize', () => {
//   clearTimeout(window.sliderResizeTimeout);
//   window.sliderResizeTimeout = setTimeout(() => {
//     initResponsiveSlider();
//   }, 300);
// });




function getItemsCount(width) {
  if (width > 1600) return 6.5;
  else if (width > 1440) return 5.5;
  else if (width > 1024) return 4.9;
  else if (width > 830) return 4.1;
  else if (width > 612) return 3.2;
  else if (width > 570) return 2.8;
  else if (width > 430) return 2.3;
  else if (width > 370) return 1.7;
  else return 1.2;
}

function initRelatedProductsProd() {
  const container = document.querySelector('.product-items');
  if (!container) return;

  const itemsCount = getItemsCount(container.offsetWidth);

  $('.related-products-prod').trigger('destroy.owl.carousel').owlCarousel({
    center: false,
    loop: true,
    dots: false,
    margin: 20,
    rtl: true,
    items: itemsCount,
  });
}

function initRelatedProducts() {
  const container = document.querySelector('.product-items');
  if (!container) return;

  const itemsCount = getItemsCount(container.offsetWidth);

  $('.related-products').trigger('destroy.owl.carousel').owlCarousel({
    loop: true,
    margin: 20,
    rtl: true,
    dots: false,
    items: itemsCount,
  });
}

// اجرای اولیه
initRelatedProductsProd();
initRelatedProducts();

// واکنش به تغییر اندازه
window.addEventListener('resize', () => {
  clearTimeout(window._owlResizeTimeout);
  window._owlResizeTimeout = setTimeout(() => {
    initRelatedProductsProd();
    initRelatedProducts();
  }, 300);
});



// function getItemsCount(width) {
//   if (width > 1600) return 6.5;
//   else if (width > 1440) return 5.5;
//   else if (width > 1024) return 4.9;
//   else if (width > 830) return 4.1;
//   else if (width > 612) return 3.2;
//   else if (width > 570) return 2.8;
//   else if (width > 430) return 2.3;
//   else return 1.1;
// }

function initCrossSellSlider() {
  const container = document.querySelector('.cross-sell-slider');
  if (!container) return;

  const width = container.offsetWidth;
  const itemsCount = getItemsCount(width);

  console.log(`[CrossSell] عرض: ${width} → آیتم‌ها: ${itemsCount}`);

  $('.cross-sell-slider').trigger('destroy.owl.carousel').owlCarousel({
    center: false,
    loop: true,
    dots: false,
    nav: false,
    margin: 20,
    rtl: true,
    items: itemsCount,
  });
}

// اجرای اولیه
initCrossSellSlider();

// واکنش به تغییر اندازه فقط برای cross-sell
window.addEventListener('resize', () => {
  clearTimeout(window._crossSellTimeout);
  window._crossSellTimeout = setTimeout(() => {
    initCrossSellSlider();
  }, 300);
});


// $('.related-products').owlCarousel({
//     loop:true,
//     margin:10,
//     dots:false,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:2
//         },
//         1000:{
//             items:5
//         }
//     }
// });

// function initRelatedProductsSlider() {
//   const container = document.querySelector('.product-items');
//   if (!container) return;

//   const width = container.offsetWidth;
//   let itemsCount = 1;

//   if (width > 1000) itemsCount = 5;
//   else if (width > 600) itemsCount = 2;
//   else itemsCount = 1;

//   $('.related-products').trigger('destroy.owl.carousel').owlCarousel({
//     loop: true,
//     margin: 10,
//     rtl: true,
//     dots: false,
//     items: itemsCount,
//   });
// }


// $('.cross-sell-slider').owlCarousel({
//     loop:true,
// 	center:false,
//     dots:false,
//     nav:false,
//     margin:5,
//     rtl:true,
//     responsive:{
//         0:{
//             items:1
//         },
// 		 430:{
//             items:1.2
//         },
// 		 500:{
//             items:1.5
//         },
//         570:{
//             items:2.2
//         },
//         820:{
//             items:3.1
//         },
// 		   868:{
//             items:2.8
//         },
// 		 1024:{
//             items:3.2
//         },
// 		 1025:{
//             items:1
//         },
// 		 1120:{
//             items:1.05
//         },
//         1280:{
//             items:1.1
//         },
// 		  1920:{
//             items:1.1
//         }
//     }
// });

// function initCrossSellSlider() {
//   const container = document.querySelector('.product-items');
//   if (!container) return;

//   const width = container.offsetWidth;
//   let itemsCount = 1;

//   if (width > 1920) itemsCount = 1.1;
//   else if (width > 1280) itemsCount = 1.1;
//   else if (width > 1120) itemsCount = 1.05;
//   else if (width > 1025) itemsCount = 1;
//   else if (width > 1024) itemsCount = 3.2;
//   else if (width > 868) itemsCount = 2.8;
//   else if (width > 820) itemsCount = 3.1;
//   else if (width > 570) itemsCount = 2.2;
//   else if (width > 500) itemsCount = 1.5;
//   else if (width > 430) itemsCount = 1.2;
//   else itemsCount = 1;

//   $('.cross-sell-slider').trigger('destroy.owl.carousel').owlCarousel({
//     center: false,
//     loop: true,
//     dots: false,
//     nav: false,
//     margin: 5,
//     rtl: true,
//     items: itemsCount,
//   });
// }




$(document).ready(function (){
    $('.hum-menu ul.sub-menu').prev('a').append("<i class='sub-menu-arrow fa fa-angle-left'></i>");

    $(".hum-menu a").has(".fa-angle-left").click(function (e) {
        e.preventDefault(); 

        var icon = $(this).find(".sub-menu-arrow"); 

        if (icon.hasClass("fa-angle-left")) {
            $(this).next("ul.sub-menu").slideToggle(); 
            icon.removeClass("fa-angle-left").addClass("fa-angle-down"); 
        } else {
            $(this).next("ul.sub-menu").hide(500); 
            icon.removeClass("fa-angle-down").addClass("fa-angle-left"); 
        }
    });
});



/* Set the width of the side navigation to 250px and the left margin of the page content to 250px and add a black background color to body */
function openNav() {
    document.getElementById("side-shop").style.display = "block";
  }
  
  /* Set the width of the side navigation to 0 and the left margin of the page content to 0, and the background color of body to white */
  function closeNav() {
    document.getElementById("side-shop").style.display = "none";
  }





  
// Elements
const emojiInputs = document.querySelectorAll(".emoji-input");
// Emoji List
const mojis = [
    "🤬",
    "🤬",
    "🤬",
    "😡",
    "😡",
    "😡",
    "😡",
    "😡",
    "😡",
    "😡",

    "😠",
    "😠",
    "😠",
    "😠",
    "😠",
    "😠",
    "😠",
    "😠",
    "😠",
    "😠",

    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",
    "🥴",


    "😵",
    "😵",
    "😵",
    "😵",
    "😵",
    "😵",
    "😵",
    "😵",
    "😵",
    "😵",

    "😑",
    "😑",
    "😑",
    "😑",
    "😑",
    "😑",
    "😑",
    "😑",
    "😑",
    "😑",

    "😐",
    "😐",
    "😐",
    "😐",
    "😐",
    "😐",
    "😐",
    "😐",
    "😐",
    "😐",

    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",
    "🙂",


    "😊",
    "😊",
    "😊",
    "😊",
    "😊",
    "😊",
    "😊",
    "😊",
    "😊",
    "😊",


    "😉",
    "😉",
    "😉",
    "😉",
    "😉",
    "😉",
    "😉",
    "😉",
    "😉",
    "😉",


    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",
    "🤩",

];


// Event Listener To Change Emoji
emojiInputs.forEach((input) => {
    input.addEventListener("input", (e) => {
        let rangeValue = e.target.value;
        console.log(rangeValue);
        const emojielement = e.target.nextElementSibling;
        emojielement.textContent = mojis[rangeValue];
    });
});



document.addEventListener("DOMContentLoaded", function () {
  const insShare = document.getElementById("ins-share");
  const overlayIns = document.getElementById("overlay-ins");
  const modalInstaShare = document.getElementById("modal-insta-share");
  const closeBtnInsShare = document.getElementById("close-btn-ins-share");

	
  if (insShare && overlayIns && modalInstaShare && closeBtnInsShare) {
    insShare.addEventListener("click", function () {
      overlayIns.classList.add("is-visible");
      modalInstaShare.classList.add("is-visible");
    });

    closeBtnInsShare.addEventListener("click", function () {
      overlayIns.classList.remove("is-visible");
      modalInstaShare.classList.remove("is-visible");
    });

    overlayIns.addEventListener("click", function () {
      overlayIns.classList.remove("is-visible");
      modalInstaShare.classList.remove("is-visible");
    });
  } else {
    console.warn("Some elements are missing from the DOM. Event listeners were not added.");
  }
});





/**
 * Switch Form Login
 */
// $('.message a').click(function(){
//     $('.form-login-pishro form').animate({height: "toggle", opacity: "toggle"}, "slow");
// });
//
// $(document).click(function (e) {
//     $('.content-ajax-search').removeClass('show');
//     $('.loader-ajax-search').removeClass('show');
//
//     if (!$(e.target).closest('.search-main').length) {
//         $('.overlay').removeClass('show');
//     }
// });


  