<?php
//require_once __DIR__.'/activatezhk/validate-locked.php';
//add_action('template_redirect', function () {
//    if ( ! \d3033acc835e6b267af648f0f::e0a96e7d0985372e94c2a9a739ac() ) {
//        $html = '
//        <div style="text-align: center; padding: 10px; font-family: Tahoma ;">
//            <img src="' . get_template_directory_uri() . '/assets/image/licnece.png" alt="License Required" style="max-width: 650px; border-radius: 8px; ">
//            <h2 style="color: #f48d70;">اگر لایسنس نداری:</h2>
//            <a style="    font-size: 16px;
//
//    border: 1px solid #f48d70;
//    padding: 10px;
//    border-radius: 8px;
//    text-decoration: none;
//    font-family: tahoma;
//    font-weight: 800;
//    background-color: #f48d70;
//    color: white;
//    box-shadow: none;" href="https://www.zhaket.com/web/ultra-market-theme" style="font-size: 16px; color: #555;">خرید از ژاکت </a>  </div>';
//        wp_die($html, '', ['response' => 403]);
//    }
//});

function add_theme_scripts()
{
    wp_enqueue_style('all', get_template_directory_uri() . '/assets/css/all.min.css', array(), false, 'all');
    wp_enqueue_style('owl.carousel.min', get_template_directory_uri() . '/assets/css/owl.carousel.min.css', array(), false, 'all');
    wp_enqueue_style('owl.theme.default', get_template_directory_uri() . '/assets/css/owl.theme.default.min.css', array(), false, 'all');
    wp_enqueue_style('zuck.css', get_template_directory_uri() . '/assets/css/zuck.css', array(), false, 'all');
    wp_enqueue_style('snapgram', get_template_directory_uri() . '/assets/css/snapgram.css', array(), false, 'all');
    wp_enqueue_style('style', get_stylesheet_uri());

    wp_enqueue_script('main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), false, true);
    wp_enqueue_script('owl.carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), false, true);
    wp_enqueue_script('carousel-slider', get_template_directory_uri() . '/assets/js/carousel-slider.js', array('jquery'), false, true);
    wp_enqueue_script('ajax_add_to_cart', get_template_directory_uri() . '/assets/js/ajax_add_to_cart.js', array('jquery'), false, true);
    wp_enqueue_script('pop', get_template_directory_uri() . '/assets/js/pop.js', array('jquery'), false, true);
    wp_enqueue_script('menu-mobile', get_template_directory_uri() . '/assets/js/menu-mobile.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'add_theme_scripts');
add_action('wp_enqueue_scripts', 'add_theme_scripts');
function ultra_theme_support()
{
    add_theme_support('title-tag');
    add_theme_support('automatic-feed-links');
    add_theme_support('post-thumbnails');
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    add_theme_support('elementor');
    add_image_size('article', 441, 229, true);
    add_image_size('blog_sidebar', 339, 176, true);
    add_image_size('product', 200, 200, true);
    register_nav_menus(
        array(
            'mainMenu' => __('جایگاه فهرست اصلی سایت'),
            'megaMenu' => __('جایگاه فهرست مگامنو سایت'),
            'mobileMenu' => __('جایگاه فهرست موبایل سایت'),
            'cart-empty-menu' => __('جایگاه فهرست سبد خالی سایت'),
        )
    );
}
add_action('after_setup_theme', 'ultra_theme_support');
//\d3033acc835e6b267af648f0f::e4104ac15a69cf0b703a1dc();
add_action('init','ultra_admin_bar');
function ultra_admin_bar(){
     include_once get_template_directory() . '/inc/adminbar/adminbar.php';
}

//get_template_part('inc/customPostType/tv');
//get_template_part('inc/customPostType/insta');
get_template_part('inc/comment/commentTemplate');
get_template_part('inc/breadcrumb/breadcrumb');
get_template_part('inc/widget/recent_post_widget');
get_template_part('inc/widget/recent_tv_post_widget.php');
get_template_part('inc/widget/about_footer');
get_template_part('inc/widget/application_footer');
get_template_part('inc/widget/social_media_footer');
get_template_part('inc/widget/address_footer');
get_template_part('inc/widget/up', 'button');
/**
 * Add a sidebar.
 */
function ultra_sidebar()
{
    register_sidebar(array(
        'name' => __('ناحیه کناری بلاگ'),
        'id' => 'ultra_sidebar_blog',
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<div class="widget-header"><span>',
        'after_title' => '</span></div>',
    ));
    register_sidebar(array(
        'name' => __('ناحیه کناری تلویزیون'),
        'id' => 'ultra_sidebar_tv',
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<div class="widget-header"><span>',
        'after_title' => '</span></div>',
    ));
    register_sidebar(array(
        'name' => __('ناحیه کناری فروشگاه'),
        'id' => 'ultra_sidebar_shop',
        'before_widget' => '<div id="%1$s" class="%2$s widget">',
        'after_widget' => '</div>',
        'before_title' => '<div class="widget-header"><span>',
        'after_title' => '</span></div>',
    ));
    register_sidebar(array(
        'name' => __('ناحیه کناری سرچ'),
        'id' => 'ultra_sidebar_search',
        'before_widget' => '<div id="%1$s" class="%2$s widget">',
        'after_widget' => '</div>',
        'before_title' => '<div class="widget-header"><span>',
        'after_title' => '</span></div>',
    ));
    register_sidebar(array(
        'name' => __('جایگاه فوتر 1'),
        'id' => 'ultra_footer1',
        'before_widget' => '<aside class="footer-widget footer-about">',
        'after_widget' => '</aside>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => __('جایگاه فوتر 2'),
        'id' => 'ultra_footer2',
        'before_widget' => '<aside class="footer-widget footer-2">',
        'after_widget' => '</aside>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => __('جایگاه فوتر 3'),
        'id' => 'ultra_footer3',
        'before_widget' => '<aside class="footer-widget footer-3">',
        'after_widget' => '</aside>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => __('جایگاه فوتر 4'),
        'id' => 'ultra_footer4',
        'before_widget' => '<aside class="footer-widget footer-4">',
        'after_widget' => '</aside>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
}

add_action('widgets_init', 'ultra_sidebar');
/**
 * Start Woocommerce
 */
if (class_exists('WooCommerce')) {
    get_template_part('inc/woocommerce/woo', 'function');
    /**
     * Add the AJAX fetch JS
     */
 add_action('wp_footer', 'fetch_ajax');
    function fetch_ajax()
    {
        ?>
        <script type="text/javascript">
            function fetch(targetInput, targetContent) {
                jQuery(targetContent).addClass('show');
                jQuery.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'post',
                    data: {
                        action: 'data_fetch',
                        keyword: jQuery(targetInput).val()
                    },
                    success: function (data) {
                        jQuery(targetContent).html(data);
                    }
                });
            }
        </script>
        <?php
    }

// The AJAX function
    add_action('wp_ajax_data_fetch', 'data_fetch');
    add_action('wp_ajax_nopriv_data_fetch', 'data_fetch');
    function data_fetch()
    {
        $keyword = esc_attr($_POST['keyword']);

        // استفاده از WP_Query برای جستجو فقط در عنوان محصولات
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 5,
            'post_status' => 'publish',
            's' => $keyword,
        );

        $the_query = new WP_Query($args);

        if ($the_query->have_posts()) : ?>
            <ul>
                <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                    <li>
                        <a href="<?php the_permalink(); ?>">
                            <?php
                            echo(has_post_thumbnail() ? get_the_post_thumbnail(get_the_ID(), array(200, 200), array('class' => 'main-img')) : wc_placeholder_img('woocommerce_thumbnail'));
                            ?>
                            <div>
                                <h3><?php the_title(); ?></h3>
                                <?php global $product;
                                echo $product->get_price_html(); ?>
                            </div>
                        </a>
                    </li>
                <?php endwhile; ?>
            </ul>
            <!-- دکمه مشاهده دیگر نتایج -->
            <div class="view-more-results">
                <a href="<?php echo home_url('/?s=' . urlencode($keyword)); ?>" class="btn-view-more">
                    مشاهده محصولات بیشتر
                </a>
            </div>
            <?php wp_reset_postdata();
        else : ?>
            <div class="not-found-search">
                <img src="<?php global $ultra_options;
                echo $ultra_options['ultra-search-img']['url']; ?>">
                <p><?php echo $ultra_options['ultra-search-text']; ?></p>
            </div>
        <?php endif;

        die();
    }


    add_action('wp_ajax_ql_woocommerce_ajax_add_to_cart', 'ql_woocommerce_ajax_add_to_cart');
    add_action('wp_ajax_nopriv_ql_woocommerce_ajax_add_to_cart', 'ql_woocommerce_ajax_add_to_cart');
    function ql_woocommerce_ajax_add_to_cart()
    {
        $product_id = apply_filters('ql_woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
        $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
        $variation_id = absint($_POST['variation_id']);
        $passed_validation = apply_filters('ql_woocommerce_add_to_cart_validation', true, $product_id, $quantity);
        $product_status = get_post_status($product_id);
        if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id) && 'publish' === $product_status) {
            do_action('ql_woocommerce_ajax_added_to_cart', $product_id);
            if ('yes' === get_option('ql_woocommerce_cart_redirect_after_add')) {
                wc_add_to_cart_message(array($product_id => $quantity), true);
            }
            WC_AJAX:: get_refreshed_fragments();
        } else {
            $data = array(
                'error' => true,
                'product_url' => apply_filters('ql_woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id));
            echo wp_send_json($data);
        }
        wp_die();
    }
}


function more_read_shortcode($atts)
{
  
    $atts = shortcode_atts(
        array(
            'id' => '', 
        ),
        $atts
    );


    if (!$atts['id']) {
        return '';
    }

  
    $link = get_permalink($atts['id']);
    $title = get_the_title($atts['id']);

    if (!$link || !$title) {
        return ''; 
    }


    return '<div class="more-read"><a href="' . esc_url($link) . '" target="_blank">بیشتر بخوانید: ' . esc_html($title) . '</a></div>';
}

add_shortcode('more_read', 'more_read_shortcode');

/**
 * Redux
 */
if (!class_exists('ReduxFramework') && file_exists(dirname(__FILE__) . '/inc/settingTheme/redux-core/framework.php')) {
    require_once dirname(__FILE__) . '/inc/settingTheme/redux-core/framework.php';
}
if (!isset($redux_demo) && file_exists(require_once dirname(__FILE__) . '/inc/settingTheme/sample/sample-config.php')) {
    require_once dirname(__FILE__) . '/inc/settingTheme/sample/sample-config.php';
}
require_once dirname(__FILE__) . '/inc/settingTheme/custom-style.php';
/**
 * Custom Style Redux FrameWork : Custom Style settingTheme
 */
add_action('admin_enqueue_scripts', 'redux_custom_style');
function redux_custom_style()
{
    wp_enqueue_style('redux-custom', get_template_directory_uri() . '/assets/css/reduxSettingTheme.css');
}

/**
 * Filter the except length to 20 words.
 */
function related_single_blog_custom_excerpt_length($length)
{
    global $ultra_options;
    return $ultra_options['related_post_custom_expert'];
}

add_filter('excerpt_length', 'related_single_blog_custom_excerpt_length', 999);

/**
 * Elementor UltraMarket
 */
 
//\d3033acc835e6b267af648f0f::a028f356f2c1b298b2b1c9779e7831d();
add_action('init','elementor_ultra');
function elementor_ultra(){
    require_once 'inc/elementor/elementor.php';
}


/**
 *  Disable Gutenberge For Blog & Widget
 */

add_action('init', 'disable_gutenberg_based_on_settings');
function disable_gutenberg_based_on_settings()
{
    global $ultra_options;


    if (isset($ultra_options['choose_editor_blog']) && $ultra_options['choose_editor_blog']) {
        add_filter('use_block_editor_for_post', '__return_false', 10);
    }

    if (isset($ultra_options['choose_editor_widget']) && $ultra_options['choose_editor_widget']) {
        add_filter('use_widgets_block_editor', '__return_false', 10);
    }
}

add_action('template_redirect', function () {
    global $ultra_options;

    if (!empty($ultra_options['maintenance_enable']) && $ultra_options['maintenance_enable']) {
        if (!current_user_can('edit_themes') && !is_user_logged_in()) {
            $header_message = isset($ultra_options['h1_maintenance_message']) ? esc_html($ultra_options['h1_maintenance_message']) : 'در حال بروزرسانی';
            $body_message = isset($ultra_options['maintenance_message']) ? esc_html($ultra_options['maintenance_message']) : 'وب‌سایت به زودی در دسترس خواهد بود.';
            $image_url = isset($ultra_options['maintenance_image']['url']) ? esc_url($ultra_options['maintenance_image']['url']) : '';

            wp_die('
                <div class="maintenance" style="text-align: center; padding: 50px;">
                    <h1 class="maintenance_header" style="font-size: 24px; margin-bottom: 20px;">' . $header_message . '</h1>
                    <p class="maintenance_body" style="font-size: 18px; margin-bottom: 20px;">' . $body_message . '</p>
                    ' . (!empty($image_url) ? '<img class="maintenance_img" src="' . $image_url . '" alt="Maintenance" style="max-width: 100%; height: auto; margin-bottom: 20px;">' : '') . '
                </div>
            ', __('حالت تعمیر', 'text-domain'), array('response' => 503));
        }
    }
});


/**
 * Tgm Activation Plugins
 */
require_once 'inc/class-tgm-plugin-activation.php';

add_action('tgmpa_register', 'mytheme_require_plugins');
function mytheme_require_plugins()
{
    $plugins = array(
        array(
            'name' => 'المنتور',
            'slug' => 'elementor',
            'required' => true,
        ),
        array(
            'name' => 'ووکامرس',
            'slug' => 'woocommerce',
            'required' => true,
        ),
        array(
            'name' => 'منو آیکون',
            'slug' => 'menu-icons',
            'required' => false,
        ),
    );
    $config = array(
        'id'           => 'tgmpa',                 // Unique ID for hashing notices for multiple instances of TGMPA.
        'default_path' => '',                      // Default absolute path to bundled plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message'      => '',
    );
    tgmpa( $plugins, $config );
}
// combine wishlist
//\d3033acc835e6b267af648f0f::b34ef38f5c663612b8211acb49d4b7d();
add_action('after_setup_theme','mytheme_load_woosw');
function mytheme_load_woosw()
{
    if (class_exists('WooCommerce') && !function_exists('woosw_init')) {
        require_once 'inc/plugins/wishlist/wpc-smart-wishlist.php';
        woosw_init();
    }
}
// combine variable swatches
add_action('after_setup_theme', 'include_woo_variation_swatches');
function include_woo_variation_swatches()
{
    if (class_exists('WooCommerce') && !class_exists('Woo_Variation_Swatches')) {
        require_once 'inc/plugins/swatches/woo-variation-swatches.php';
        woo_variation_swatches();
    } else null;
}
// Load the plugin
require_once get_template_directory() . '/inc/plugins/invoice/pepro-ultimate-invoice.php';

// Initialize the plugin
function ultramarket_init_pepro_ultimate_invoice() {
    global $PeproUltimateInvoice;
    if (!isset($PeproUltimateInvoice)) {
        $PeproUltimateInvoice = new \pepro_ultimate_invoice\Pepro_Ultimate_Invoice();
    }
}
add_action('after_setup_theme', 'ultramarket_init_pepro_ultimate_invoice');
// Enqueue scripts and styles
// function ultramarket_enqueue_invoice_scripts() {
//     wp_enqueue_style('pepro-invoice-style', get_template_directory_uri() . '/inc/plugins/invoice/assets/css/style.css');
//    wp_enqueue_script('pepro-invoice-script', get_template_directory_uri() . '/inc/plugins/invoice/assets/js/script.js', array('jquery'), null, true);
// }
// add_action('admin_enqueue_scripts', 'ultramarket_enqueue_invoice_scripts');
function ultra_register_html_post_type() {
    register_post_type('ultra_html', array(
        'labels' => array(
            'name' => 'اولترا سکشن',
            'singular_name' => 'اولترا سکشن',
            'add_new' => 'افزودن سکشن جدید',
            'add_new_item' => 'افزودن سکشن  جدید',
            'edit_item' => 'ویرایش سکشن اولترا',
        ),
        'public' => true,
		 'show_in_menu' => 'ultra-theme-settings', 
        
        'menu_icon' => 'dashicons-editor-code',
        'supports' => array('title', 'editor'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'ultra_register_html_post_type');
function ultra_generate_random_code() {
    return 'ultra-' . rand(10000, 99999);
}
function ultra_save_html_code_meta($post_id) {
    if (get_post_type($post_id) !== 'ultra_html') return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    $existing = get_post_meta($post_id, '_ultra_extra_code', true);
    if (!$existing) {
        $code = ultra_generate_random_code();
        update_post_meta($post_id, '_ultra_extra_code', $code);
    }
}
add_action('save_post', 'ultra_save_html_code_meta');
function ultra_html_shortcode_column($columns) {
    $columns['shortcode'] = 'شورتکد';
    return $columns;
}
add_filter('manage_ultra_html_posts_columns', 'ultra_html_shortcode_column');
function ultra_html_shortcode_column_content($column, $post_id) {
    if ($column === 'shortcode') {
        $code = get_post_meta($post_id, '_ultra_extra_code', true);
        if ($code) {
            $shortcode = '[ultra-extra-code code="' . $code . '"]';
            echo '<input type="text" readonly value="' . esc_attr($shortcode) . '" style="width: 280px; direction: ltr; font-family: monospace; padding: 4px;" onclick="this.select(); document.execCommand(\'copy\');">';
        } else {
            echo '—';
        }
    }
}
add_action('manage_ultra_html_posts_custom_column', 'ultra_html_shortcode_column_content', 10, 2);
function ultra_render_extra_html_shortcode($atts) {
    $atts = shortcode_atts(array(
        'code' => ''
    ), $atts, 'ultra-extra-code');

    if (!$atts['code']) return '';

    $query = new WP_Query(array(
        'post_type' => 'ultra_html',
        'meta_key' => '_ultra_extra_code',
        'meta_value' => $atts['code'],
        'posts_per_page' => 1,
    ));

    if ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        if (\Elementor\Plugin::instance()->documents->get($post_id)->is_built_with_elementor()) {
            return \Elementor\Plugin::instance()->frontend->get_builder_content($post_id);
        } else {
            return apply_filters('the_content', get_post_field('post_content', $post_id));
        }
    }

    return '<!-- HTML اضافی یافت نشد -->';
}
add_shortcode('ultra-extra-code', 'ultra_render_extra_html_shortcode');
function ultra_register_custom_header_footer_post_types() {
    register_post_type('ultra_header', array(
        'labels' => array(
            'name' => 'هدر اولترا',
            'singular_name' => 'هدر اولترا',
            'add_new' => 'افزودن هدر جدید',
            'add_new_item' => 'افزودن هدر جدید',
            'edit_item' => 'ویرایش هدر',
            'new_item' => 'هدر جدید',
            'all_items' => 'اولترا هدر',
            'view_item' => 'مشاهده هدر',
            'search_items' => 'جستجوی هدر',
        ),
        'public' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
		 'show_in_menu' => 'ultra-theme-settings', 
        'menu_icon' => 'dashicons-heading',
        'supports' => array('title', 'editor'),
        'show_in_rest' => true,
        'has_archive' => false,
        'rewrite' => false
    ));

    // پست تایپ فوتر
    register_post_type('ultra_footer', array(
        'labels' => array(
            'name' => 'فوتر اولترا',
            'singular_name' => 'فوتر',
            'add_new' => 'افزودن فوتر جدید',
            'add_new_item' => 'افزودن فوتر جدید',
            'edit_item' => 'ویرایش فوتر',
            'new_item' => 'فوتر جدید',
            'all_items' => 'اولترا فوتر',
            'view_item' => 'مشاهده فوتر',
            'search_items' => 'جستجوی فوتر',
        ),
        'public' => true,
        'show_in_menu' => true,
        'menu_position' => 21,
		 'show_in_menu' => 'ultra-theme-settings', 
        'menu_icon' => 'dashicons-pets',
        'supports' => array('title', 'editor'),
        'show_in_rest' => true,
        'has_archive' => false,
        'rewrite' => false
    ));
}
add_action('init', 'ultra_register_custom_header_footer_post_types');
/**
 * 
 **/
// Check if another plugin or theme has bundled ACF
if ( defined( 'MY_ACF_PATH' ) ) {
    return;
}
// Define path and URL to the ACF plugin.
define( 'MY_ACF_PATH', get_template_directory() . '/inc/plugins/acf/' );
define( 'MY_ACF_URL', get_template_directory_uri() . '/inc/plugins/acf/' );
// Include the ACF plugin.
include_once 'inc/plugins/acf/acf.php';

// Customize the URL setting to fix incorrect asset URLs.
add_filter('acf/settings/url', 'my_acf_settings_url');
function my_acf_settings_url( $url ) {
    return MY_ACF_URL;
}
require_once 'inc/plugins/acf-fields.php';
// Check if ACF free is installed
if ( ! file_exists( WP_PLUGIN_DIR . '/advanced-custom-fields/acf.php' ) ) {
    // Free plugin not installed
    // Hide the ACF admin menu item.
    add_filter( 'acf/settings/show_admin', '__return_false' );
    // Hide the ACF Updates menu
    add_filter( 'acf/settings/show_updates', '__return_false', 100 );
}




// کد تغییر تومان به متن یا المان دلخواه که باید در functions.php گذاشته شود

add_filter('woocommerce_currency_symbol', function($currency_symbol, $currency) {
    if ($currency === 'IRT') {
        $currency_symbol = '<svg width="24" height="14" viewBox="0 0 24 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.8572 4.52C17.4292 4.52 17.9319 4.65 18.3652 4.91C18.7986 5.17 19.1279 5.53833 19.3532 6.015C19.5872 6.49167 19.7042 7.04633 19.7042 7.679V8.55H21.2642C21.6629 8.55 21.9446 8.485 22.1092 8.355C22.2739 8.21633 22.3476 8.02133 22.3302 7.77C22.3129 7.52733 22.2696 7.20233 22.2002 6.795C22.1309 6.379 22.0572 5.98467 21.9792 5.612L23.5392 5.222C23.6432 5.65533 23.7386 6.12767 23.8252 6.639C23.9206 7.14167 23.9726 7.55767 23.9812 7.887C23.9899 8.32033 23.8989 8.732 23.7082 9.122C23.5176 9.50333 23.2272 9.81533 22.8372 10.058C22.4472 10.3007 21.9662 10.422 21.3942 10.422H19.6912V10.474C19.6912 11.1153 19.5612 11.683 19.3012 12.177C19.0499 12.6797 18.6512 13.074 18.1052 13.36C17.5679 13.646 16.8876 13.789 16.0642 13.789H14.5172V11.917H16.0642H16.2202C16.6969 11.9083 17.0652 11.8563 17.3252 11.761C17.5939 11.6657 17.7802 11.5183 17.8842 11.319C17.9882 11.1197 18.0402 10.838 18.0402 10.474V10.422H17.1692C16.6839 10.422 16.2679 10.3873 15.9212 10.318C15.5832 10.2487 15.1976 10.1013 14.7642 9.876C14.5562 10.058 14.3309 10.2097 14.0882 10.331C13.8456 10.4437 13.6029 10.5 13.3602 10.5H12.9832C12.3766 10.5 11.8782 10.3743 11.4882 10.123C11.0982 9.87167 10.8122 9.52933 10.6302 9.096C10.4482 8.66267 10.3572 8.15567 10.3572 7.575V3.662C10.3572 3.51467 10.3182 3.402 10.2402 3.324C10.1709 3.246 10.0496 3.207 9.87622 3.207H9.51222C9.33022 3.207 9.20022 3.246 9.12222 3.324C9.05289 3.39333 9.01822 3.506 9.01822 3.662V9.278C9.01822 10.3093 8.71922 11.1283 8.12122 11.735C7.52322 12.3503 6.61755 12.658 5.40422 12.658H4.28622C3.50622 12.658 2.83889 12.4847 2.28422 12.138C1.72955 11.7913 1.30922 11.319 1.02322 10.721C0.737219 10.1317 0.594219 9.47733 0.594219 8.758C0.594219 8.22933 0.685219 7.666 0.867219 7.068C1.04922 6.46133 1.26589 5.90667 1.51722 5.404L2.89522 6.145C2.67855 6.60433 2.50955 7.05067 2.38822 7.484C2.27555 7.91733 2.21922 8.342 2.21922 8.758C2.21922 9.20867 2.28422 9.58133 2.41422 9.876C2.55289 10.1707 2.76955 10.396 3.06422 10.552C3.36755 10.708 3.77489 10.786 4.28622 10.786H5.40422C5.93289 10.786 6.33589 10.7383 6.61322 10.643C6.89055 10.5563 7.08555 10.409 7.19822 10.201C7.31089 9.98433 7.36722 9.67667 7.36722 9.278V3.532C7.36722 3.07267 7.43655 2.68267 7.57522 2.362C7.72255 2.03267 7.95222 1.78133 8.26422 1.608C8.58489 1.426 8.99655 1.335 9.49922 1.335H9.88922C10.3746 1.335 10.7732 1.426 11.0852 1.608C11.4059 1.78133 11.6399 2.03267 11.7872 2.362C11.9346 2.68267 12.0082 3.064 12.0082 3.506V7.575C12.0082 7.90433 12.0299 8.13833 12.0732 8.277C12.1166 8.41567 12.2032 8.511 12.3332 8.563C12.4632 8.60633 12.6929 8.628 13.0222 8.628H13.3472C13.5119 8.628 13.6376 8.589 13.7242 8.511C13.8196 8.42433 13.8932 8.28567 13.9452 8.095L14.2702 6.847C14.4696 6.093 14.7946 5.51667 15.2452 5.118C15.6959 4.71933 16.2332 4.52 16.8572 4.52ZM15.5832 8.225C15.8952 8.36367 16.1682 8.46767 16.4022 8.537C16.6449 8.59767 16.9006 8.628 17.1692 8.628H18.0532V7.679C18.0532 7.24567 17.9666 6.912 17.7932 6.678C17.6199 6.43533 17.3339 6.314 16.9352 6.314C16.6752 6.314 16.4499 6.405 16.2592 6.587C16.0686 6.76033 15.9256 7.02467 15.8302 7.38L15.5832 8.225ZM5.14422 3.805C5.43022 3.805 5.71189 3.805 5.98922 3.805V5.508H5.14422C4.86689 5.508 4.58522 5.508 4.29922 5.508V3.805H5.14422ZM22.7852 3.831C22.5426 3.831 22.3606 3.831 22.2392 3.831C22.1266 3.831 21.9532 3.831 21.7192 3.831H21.1342V2.284H22.7852V3.831ZM19.5482 3.831V2.284H21.2122V3.831H19.5482Z" fill="black"/>
</svg>
';
    }
    return $currency_symbol;
}, 10, 2);

