<?php get_header() ?>
<div class="archive-product category-product-page">
    <div class="container">
        <?php if (function_exists('ultra_breadcrumb')) { ?>
            <nav class="breadcrumb-ultra">
                <?php echo ultra_breadcrumb(); ?>
            </nav>
        <?php } ?>
        <div class="archive-content">
            <div class="page_404">
                <div class="media_404">
            <?php global $ultra_options; ?>
                    <img src="<?php echo $ultra_options['choose_404_gif']['url']; ?>">
                </div>
                <div class="text_404">
                    <p><?php echo $ultra_options['text_404'];?></p>
                </div>
                <div class="btn_404">
                    <a href="<?php echo $ultra_options['link_btn_1_404'];?>"><?php echo $ultra_options['btn_1_404'];?></a>
                    <a href="<?php echo $ultra_options['link_btn_2_404'];?>"><?php echo $ultra_options['btn_2_404'];?></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer() ?>
