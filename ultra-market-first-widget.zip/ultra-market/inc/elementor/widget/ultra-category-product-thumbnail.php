<?php

class Elementor_ultra_category_product_thumbnail extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'ultra_category_product_thumbnail';
    }

    public function get_title()
    {
        return 'نمایش دسته بندی محصولات با تصویر';
    }

    public function get_icon()
    {
        return 'eicon-products';
    }

    public function get_categories()
    {
        return ['ultra'];
    }

    public function get_keywords()
    {
        return ['product'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('المان محصولات', 'textdomain'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // انتخاب دسته بندی ها برای نمایش
        $this->add_control(
            'selected_categories',
            [
                'label' => esc_html__('دسته بندی‌های انتخابی', 'textdomain'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_category_options(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        // نمایش دسته بندی‌های خالی
        $this->add_control(
            'show_empty_categories',
            [
                'label' => esc_html__('نمایش دسته بندی‌های خالی', 'textdomain'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('بله', 'textdomain'),
                'label_off' => esc_html__('خیر', 'textdomain'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $selected_categories = !empty($settings['selected_categories']) ? $settings['selected_categories'] : [];
        $show_empty_categories = !empty($settings['show_empty_categories']) && $settings['show_empty_categories'] === 'yes';

        // دریافت دسته‌بندی‌های محصولات ووکامرس
        $args = [
            'taxonomy'   => 'product_cat',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'hide_empty' => !$show_empty_categories, // نمایش دسته‌بندی‌های خالی بر اساس تنظیمات
        ];

        if (!empty($selected_categories)) {
            $args['include'] = $selected_categories; // نمایش فقط دسته‌بندی‌های انتخابی
        }

        $product_categories = get_terms($args);

        if (!empty($product_categories) && !is_wp_error($product_categories)) {
            echo '<div class="product-categories-container">';
            foreach ($product_categories as $category) {
                $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                $thumbnail_url = wp_get_attachment_url($thumbnail_id);
                ?>
                <div class="product-category">
                    <a href="<?php echo get_term_link($category); ?>">
                        <?php if ($thumbnail_url) : ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($category->name); ?>">
                        <?php else : ?>
                            <img src="<?php echo wc_placeholder_img_src(); ?>" alt="<?php echo esc_attr($category->name); ?>">
                        <?php endif; ?>
                        <h3><?php echo esc_html($category->name); ?></h3>
                    </a>
                </div>
                <?php
            }
            echo '</div>';
        }
    }

    // دریافت گزینه‌های دسته‌بندی‌ها برای فیلد انتخابی
    private function get_category_options()
    {
        $categories = get_terms([
            'taxonomy'   => 'product_cat',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'hide_empty' => false,
        ]);

        $options = [];
        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }
}
?>
