<?php
// Add Taxonomies For Tv
add_action( 'init', 'create_brand_for_product');
function create_brand_for_product() {
    $labels = array(
        'name'              => _x( 'برندها', 'برندها' ),
        'singular_name'     => _x( 'برندها ', 'برندها' ),
        'search_items'      => __( 'جستجویه برند' ),
        'all_items'         => __( 'تمام برند ها' ),
        'parent_item'       => __( 'زیر برند' ),
        'parent_item_colon' => __( 'Parent Genre:' ),
        'edit_item'         => __( 'ویرایش برند' ),
        'update_item'       => __( 'بروزرسانی برند' ),
        'add_new_item'      => __( 'افزودن برند جدید' ),
        'new_item_name'     => __( 'نام جدید برند' ),
        'menu_name'         => __( 'برندها' ),
    );

    $br = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
    );

    register_taxonomy( 'product_brand', 'product' , $br );
}