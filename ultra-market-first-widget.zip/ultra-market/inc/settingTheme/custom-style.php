<?php
add_action('wp_head', 'custom_style', 160);
function custom_style()
{
    global $ultra_options; ?>
    <style>
        .main-header .top-header .right-side .logo-header img, .main-header-2 .mid-header .logo-sec img {
            width: <?php echo $ultra_options['width-logo-option'] ?>px;
        }
		
		@media screen and (max-width: 601px) {
    .main-header-mob .top-header .right-side .logo-header img {
        width: <?php echo $ultra_options['width-logo-option-mob'] ?>px;
    }
			
}

		footer .footer-section .footer-content .logo img {
				width: <?php echo $ultra_options['width-logo-option-foot'] ?>px;
			}
        .container {
            width: <?php echo $ultra_options['container-option'] ?>%;
        }

        :root {

            --color-primary: <?php echo $ultra_options['second-color-option'] ?>;
			
            --color-secondary: <?php echo $ultra_options['primary-color-option'] ?>;
            --color-accent: <?php echo $ultra_options['accent-color-option'] ?>;
            --color-text: <?php echo $ultra_options['color-text'] ?>;
            --color-highlight-text: <?php echo $ultra_options['color-highlight-text'] ?>;
            --color-light-text: <?php echo $ultra_options['color-light-text'] ?>;
            --color-menu: <?php echo $ultra_options['menu-color-option'] ?>;
            --color-light-bg: <?php echo $ultra_options['transparent-color-option'] ?>;
            --color-white: <?php echo $ultra_options['color-white'] ?>;
            --color-white-text: <?php echo $ultra_options['color-white-text'] ?>; 
            --color-fixed-bg: <?php echo $ultra_options['bg-body-option'] ?>;
			--color-light-white:  <?php echo $ultra_options['color-light-white'] ?>;
        }
     
        
        <?php if ($ultra_options['switch_bg_back_site'] == "off"){ ?>
        .archive-product {
            background: <?php echo $ultra_options['bg-body-option']?>;
        }

        .main-header {
            background: <?php echo $ultra_options['bg-body-option']?>;
        }

        <?php }?>

        .single-product-ultra .product-box .entry-summary .attr-prod .attr-ultra {
            border-radius: 0.8rem;
            padding: 1.6rem;
            width: 30%;
            border-top: <?php echo $ultra_options['border-additional-info-product']['border-top']; ?>;
            border-bottom: <?php echo $ultra_options['border-additional-info-product']['border-bottom']; ?>;
            border-left: <?php echo $ultra_options['border-additional-info-product']['border-left']; ?>;
            border-right: <?php echo $ultra_options['border-additional-info-product']['border-right']; ?>;
            border-style: <?php echo $ultra_options['border-additional-info-product']['border-style']; ?>;
            border-color: <?php echo $ultra_options['border-additional-info-product']['border-color']; ?>;
            background: <?php echo $ultra_options['bg-additional-info-product'] ?>;
        }

        .product_date i {
            font-size: <?= $ultra_options['width_icon_select'] ?>px;
            color: <?= $ultra_options['color_icon_select'] ?>;
        }

        .single-product-ultra .cart-side-ultra .cart-box .cm-show {
            border-top: <?php echo $ultra_options['border_view_comments_rating_product']['border-top']; ?>;
            border-bottom: <?php echo $ultra_options['border_view_comments_rating_product']['border-bottom']; ?>;
            border-left: <?php echo $ultra_options['border_view_comments_rating_product']['border-left']; ?>;
            border-right: <?php echo $ultra_options['border_view_comments_rating_product']['border-right']; ?>;
            border-style: <?php echo $ultra_options['border_view_comments_rating_product']['border-style']; ?>;
            border-color: <?php echo $ultra_options['border_view_comments_rating_product']['border-color']; ?>;
            background: <?php echo $ultra_options['color_view_comments_rating_product'] ?>;
        }

        <?php if ($ultra_options['switch_bg_back_site'] == true) : ?>
        .single-post-ultra, .archive-product {
            background: var(--Fade-to-Purple, linear-gradient(180deg, <?php echo $ultra_options['background-gradient-color-option'] ?> 0%, rgba(255, 187, 145, 0.00) 100%));
        }
        <?php endif; ?>
        <?php if ($ultra_options['switch_bg_back_site'] == false) : ?>
        :root {
            --color-fixed-bg: <?php echo $ultra_options['bg-body-option'] ?>;
        }
        body, footer {
            background: <?php echo $ultra_options['bg-body-option'] ?>;
        }
        <?php endif; ?>
        .steps .step, .steps .step:before, .steps .step:after {
            background-color: <?php echo $ultra_options['color_default_step_site'] ?>;
        }

        .steps .step.is-active, .steps .step.complete, .steps .step.is-active:before, .steps .step.is-active:after, .steps .step.complete:after, .steps .step.complete:before {
            background-color: <?php echo $ultra_options['color_primary_step_site'] ?>;
        }

        <?php if ($ultra_options['sidebar_position_shop'] == 'left') : ?>
        .archive-product .archive-content {
            flex-direction: row-reverse;
        }

        <?php endif; ?>
        <?php if ($ultra_options['sidebar_position_shop'] == 'none') : ?>
        .side-single {
            display: none !important;
        }
        <?php endif;
        if ($ultra_options['ultra-logo-background']) :?>
        .main-header-3 .logo-sec img , .main-header-2 .mid-header .logo-sec img , .top-header .right-side .logo-header img {
            background-color: <?php echo $ultra_options['logo-background-color'] ?>;
        }
        <?php endif; ?>
        <?php
        if ($ultra_options['ultra-logo-background-footer']) :?>
        footer .footer-section .footer-content .logo img {
            background-color: <?php echo $ultra_options['logo-background-color-footer'] ?>;
        }
        <?php endif; ?>
        <?php
        if (!$ultra_options['active_contact_us_mobile']) { ?>
            @media screen and (max-width: 576px ) {
                .floating-contact {
                    display: none;
                }
            }

        <?php } 
        if(!$ultra_options['top_down_content']){ ?>
        .f-insale-content {
            flex-direction: column-reverse;
        }
        <?php } ?>


        <?php echo $ultra_options['custom_css_editor'];
        $popup_position = isset($ultra_options['product_display_select']) ? $ultra_options['product_display_select'] : 'top_right';
        // اضافه کردن استایل داینامیک بر اساس انتخاب کاربر
        switch ($popup_position) {
            case 'top_right':
            echo '.message-box-ultra { bottom: unset; top: 5rem; right: -15rem; }';
            break;
            case 'top_center':
            echo '.message-box-ultra { bottom: unset; top: 5rem; left: 50%; transform: translateX(-50%); }';
            break;
            case 'left_center':
            echo '.message-box-ultra { bottom: unset; top: 50%; left: 2rem; transform: translateY(-50%); }';
            break;
            case 'top_left':
            echo '.message-box-ultra { bottom: unset; top: 5rem; left: 20rem; }';
            break;
            case 'bottom_right':
            echo '.message-box-ultra { bottom: 2rem; top: unset; right: -15rem; }';
            break;
            case 'bottom_center':
            echo '.message-box-ultra { bottom: 2rem; top: unset; left: 50%; transform: translateX(-50%); }';
            break;
            case 'right_center':
            echo '.message-box-ultra { bottom: unset; top: 50%; right: -15rem; transform: translateY(-50%); }';
            break;
            case 'bottom_left':
            echo '.message-box-ultra { bottom: 2rem; top: unset; left: 20rem; }';
            break;
            default:
                    echo '.message-box-ultra { bottom: unset; top: 5rem; right: 2rem; }';
            break;
        } ?>
		
		/* Header sticky  */
        <?php if($ultra_options['header_sticky']){ ?>
		.sticky-head {
			position: fixed;
			top: 0;
			width: 1440px!important;
			max-width: 95%!important;
			z-index: 99999;
			background: var(--color-white);
			padding: 1rem!important;
			border-radius: 8px;
			box-shadow: 0 2px 4px 0 #0000000D;
        }
			@media screen and (max-width:1800px)
			{
				.sticky-head {
				right:2.5%;
				}
			}
        <?php } ?>
		/* End style header*/
        .free-shipping-notice {
            background-color: <?php echo $ultra_options['free-delivery-backgrand'] ?>;
            color: <?php echo $ultra_options['free-delivery-color'] ?>;
        }
    </style>

    <?php
}