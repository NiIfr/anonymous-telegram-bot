<?php get_header();
global $ultra_options;
?>


    <div class="archive-page archive-product category-product-page category-blogs">
        <div class="container">

            <!--            <nav class="breadcrumb-ultra">-->
            <!--                --><?php //if (function_exists('ultra_breadcrumb')) {
            //                    echo ultra_breadcrumb();
            //                } ?>
            <!--            </nav>-->


            <div class="archive-content">
                <?php if (is_active_sidebar('ultra_sidebar_blog')) { ?>
                    <aside class="side-single">
                        <?php dynamic_sidebar('ultra_sidebar_blog'); ?>
                    </aside>
                <?php } ?>


                <section class="category-product blogs-content">
                    <div class="product-title">
                        <h1><?php echo get_the_archive_title(); ?></h1>
                    </div>

                    <?php if ($ultra_options['select_template_blog'] == 'one_blog') : ?>
                        <div class="blogs-sec blogs-show-1">
                            <?php
                            if (have_posts()) :
                                while (have_posts()) : the_post(); ?>
                                    <div class="blog-item">
                                        <figure>
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail();
                                            } else { ?>
                                                <img src="<?= get_template_directory_uri() . '/assets/image/empty.webp' ?>"/>
                                            <?php } ?>
                                        </figure>
                                        <div class="info-blog">
                                            <a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
                                            <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
                                            <span class="cat"><?php the_category('. '); ?></span>
                                            <div class="author">
                                                <span>نویسنده : <span><?php the_author(); ?></span></span>
                                                <span><?php the_date('j F, Y'); ?></span>
                                            </div>
                                            <a class="view" href="<?php the_permalink(); ?>"> مشاهده</a>
                                        </div>
                                    </div>
                                <?php endwhile;
                            endif;
                            wp_reset_postdata();
                            ?>
                        </div>
                    <?php
                    endif;

                    if ($ultra_options['select_template_blog'] == 'two_blog') : ?>
                        <div class="blogs-sec blogs-show-2">
                            <?php
                            if (have_posts()) :
                                while (have_posts()) : the_post(); ?>
                                    <div class="blog-item">
                                        <figure>
                                            <?php if (has_post_thumbnail()) {
                                                the_post_thumbnail();
                                            } else { ?>
                                                <img src="<?= get_template_directory_uri() . '/assets/image/empty.webp' ?>"
                                            <?php } ?>
                                        </figure>
                                        <div class="info-blog">
                                            <a href="<?php the_permalink(); ?>">  <h3><?php the_title(); ?></h3></a>
                                            <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
                                            <span class="cat"><?php the_category('. '); ?></span>
                                            <div class="author">
                                                <span>نویسنده : <span><?php the_author(); ?></span></span>
                                                <span><?php the_date('j F, Y'); ?></span>
                                            </div>

                                            <a class="view" href="<?php the_permalink(); ?>">
                                                <svg  id="Show" width="24" height="24" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M12.0022 10.0361C10.6703 10.0361 9.59021 11.1155 9.59021 12.4481C9.59021 13.7799 10.6704 14.8601 12.0022 14.8601C13.334 14.8601 14.4142 13.7799 14.4142 12.4481C14.4142 11.1155 13.3342 10.0361 12.0022 10.0361ZM8.09021 12.4481C8.09021 10.2867 9.84215 8.5361 12.0022 8.5361C14.1623 8.5361 15.9142 10.2867 15.9142 12.4481C15.9142 14.6083 14.1624 16.3601 12.0022 16.3601C9.842 16.3601 8.09021 14.6083 8.09021 12.4481Z" fill="white"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M4.97577 6.99435C6.77017 5.47727 9.25098 4.39609 12.0022 4.39609C14.7529 4.39609 17.2337 5.47642 19.0282 6.99314C20.8033 8.49335 22.0042 10.5101 22.0042 12.4481C22.0042 14.3861 20.8033 16.4028 19.0282 17.903C17.2337 19.4198 14.7529 20.5001 12.0022 20.5001C9.25098 20.5001 6.77017 19.4189 4.97577 17.9018C3.20099 16.4013 2.00024 14.3846 2.00024 12.4481C2.00024 10.5116 3.20099 8.49485 4.97577 6.99435ZM5.94422 8.13983C4.3705 9.47033 3.50024 11.1046 3.50024 12.4481C3.50024 13.7916 4.3705 15.4258 5.94422 16.7564C7.49832 18.0703 9.64351 19.0001 12.0022 19.0001C14.3606 19.0001 16.5058 18.0709 18.06 16.7574C19.6337 15.4273 20.5042 13.7931 20.5042 12.4481C20.5042 11.1031 19.6337 9.46883 18.06 8.13878C16.5058 6.82525 14.3606 5.89609 12.0022 5.89609C9.64351 5.89609 7.49832 6.82591 5.94422 8.13983Z" fill="white"></path>
                                                </svg>
                                                <span>مشاهده</span>
                                            </a>
                                        </div>
                                    </div>
                                <?php endwhile;
                            endif;
                            wp_reset_postdata();
                            ?>
                        </div>

                    <?php
                    endif;

                    if ($ultra_options['select_template_blog'] == 'three_blog'): ?>
                        <div class="blogs-sec blogs-show-3">

                            <?php
                            if (have_posts()) :
                                while (have_posts()) : the_post(); ?>
                                    <div class="blog-item">
                                        <!--                                        <figure>-->
                                        <?php if (has_post_thumbnail()) {
                                            the_post_thumbnail();
                                        } else { ?>
                                            <img src="<?= get_template_directory_uri() . '/assets/image/empty.webp' ?>"
                                        <?php } ?>
                                        <!--                                        </figure>-->
                                        <div class="info-blog">
                                            <a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
                                            <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
                                            <span class="cat"><?php the_category('. '); ?></span>
                                            <div class="author">
                                                <span>نویسنده : <span><?php the_author(); ?></span></span>
                                                <span><?php the_date('j F, Y'); ?></span>
                                            </div>
                                            <a class="view" href="<?php the_permalink(); ?>">
                                                <svg id="Show" width="24" height="24" viewBox="0 0 25 25" fill="none"
                                                     xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                          d="M12.0022 10.0361C10.6703 10.0361 9.59021 11.1155 9.59021 12.4481C9.59021 13.7799 10.6704 14.8601 12.0022 14.8601C13.334 14.8601 14.4142 13.7799 14.4142 12.4481C14.4142 11.1155 13.3342 10.0361 12.0022 10.0361ZM8.09021 12.4481C8.09021 10.2867 9.84215 8.5361 12.0022 8.5361C14.1623 8.5361 15.9142 10.2867 15.9142 12.4481C15.9142 14.6083 14.1624 16.3601 12.0022 16.3601C9.842 16.3601 8.09021 14.6083 8.09021 12.4481Z"
                                                          fill="white"></path>
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                          d="M4.97577 6.99435C6.77017 5.47727 9.25098 4.39609 12.0022 4.39609C14.7529 4.39609 17.2337 5.47642 19.0282 6.99314C20.8033 8.49335 22.0042 10.5101 22.0042 12.4481C22.0042 14.3861 20.8033 16.4028 19.0282 17.903C17.2337 19.4198 14.7529 20.5001 12.0022 20.5001C9.25098 20.5001 6.77017 19.4189 4.97577 17.9018C3.20099 16.4013 2.00024 14.3846 2.00024 12.4481C2.00024 10.5116 3.20099 8.49485 4.97577 6.99435ZM5.94422 8.13983C4.3705 9.47033 3.50024 11.1046 3.50024 12.4481C3.50024 13.7916 4.3705 15.4258 5.94422 16.7564C7.49832 18.0703 9.64351 19.0001 12.0022 19.0001C14.3606 19.0001 16.5058 18.0709 18.06 16.7574C19.6337 15.4273 20.5042 13.7931 20.5042 12.4481C20.5042 11.1031 19.6337 9.46883 18.06 8.13878C16.5058 6.82525 14.3606 5.89609 12.0022 5.89609C9.64351 5.89609 7.49832 6.82591 5.94422 8.13983Z"
                                                          fill="white"></path>
                                                </svg>
                                                <span>مشاهده</span>
                                            </a>
                                        </div>
                                    </div>


                                <?php endwhile;
                            endif;
                            wp_reset_postdata();
                            ?>
                        </div>
                    <?php endif; ?>
                    <div class="navigation">
                        <?php the_posts_pagination(); ?>
                    </div>
                </section>
            </div>


        </div>
    </div>


<?php get_footer(); ?>