<?php
defined('ABSPATH') || exit ("no access");
if( empty($this->a4c3812ec146ba288d81b1091aa) ): ?>
    <div class="notice notice-error">
        <?php if (version_compare(PHP_VERSION, '7.0.0') >= 0):?>
        <p>
            <?php printf(esc_html__( 'To activating %s, please insert your license key', 'guard-gn-cea83f2a3e114d91ede77155cd49ce' ), esc_html__($this->cb8c07caf9d8c8e0c8e374f26251a35e, 'guard-gn-cea83f2a3e114d91ede77155cd49ce')); ?>
            <a href="<?php echo admin_url( 'admin.php?page='.$this->f1688448df1e144706ffb2be ); ?>" class="button button-primary"><?php _e('Active License', 'guard-gn-cea83f2a3e114d91ede77155cd49ce'); ?></a>
        </p>
        <?php else:?>
            <p>
                <?php printf(esc_html__( 'The PHP version of the website is lower than 7.0. Ask your host administrator to upgrade PHP version to activate %s. ', 'guard-gn-cea83f2a3e114d91ede77155cd49ce' ), esc_html__($this->cb8c07caf9d8c8e0c8e374f26251a35e, 'guard-gn-cea83f2a3e114d91ede77155cd49ce')); ?>
            </p>
    <?php endif; ?>
    </div>
<?php elseif( $this->cddf4c39d4533d0a2e96dd4d5405cb===true ): ?>
    <div class="notice notice-error">
        <p>
            <?php printf(esc_html__( 'Something is wrong with your %s license. Please check it.', 'guard-gn-cea83f2a3e114d91ede77155cd49ce' ), esc_html__($this->cb8c07caf9d8c8e0c8e374f26251a35e, 'guard-gn-cea83f2a3e114d91ede77155cd49ce')); ?>
            <a href="<?php echo admin_url( 'admin.php?page='.$this->f1688448df1e144706ffb2be ); ?>" class="button button-primary"><?php _e('Check Now', 'guard-gn-cea83f2a3e114d91ede77155cd49ce'); ?></a>
        </p>
    </div>
<?php endif; ?>